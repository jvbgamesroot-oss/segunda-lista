#include <stdio.h>

int main(void) {
    float v[10], q[10];
    int i;

    for (i = 0; i < 10; i++) {
        printf("Digite o valor %d: ", i + 1);
        scanf("%f", &v[i]);
        q[i] = v[i] * v[i];
    }

    printf("\nVetor original:\n");
    for (i = 0; i < 10; i++)
        printf("%.2f ", v[i]);

    printf("\nVetor dos quadrados:\n");
    for (i = 0; i < 10; i++)
        printf("%.2f ", q[i]);
    printf("\n");

    return 0;
}
