#include <stdio.h>

int main(void) {
    int v[6], i;

    for (i = 0; i < 6; i++) {
        printf("Digite o valor %d: ", i + 1);
        scanf("%d", &v[i]);
    }

    printf("Valores lidos:\n");
    for (i = 0; i < 6; i++)
        printf("%d\n", v[i]);

    return 0;
}
