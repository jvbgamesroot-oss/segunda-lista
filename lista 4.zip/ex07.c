#include <stdio.h>

int main(void) {
    int v[10], i, maior, pos = 0;

    for (i = 0; i < 10; i++) {
        printf("Digite o valor %d: ", i + 1);
        scanf("%d", &v[i]);
    }

    maior = v[0];
    for (i = 1; i < 10; i++) {
        if (v[i] > maior) {
            maior = v[i];
            pos = i;
        }
    }

    printf("Vetor: ");
    for (i = 0; i < 10; i++)
        printf("%d ", v[i]);
    printf("\nMaior elemento: %d\nPosicao: %d\n", maior, pos);

    return 0;
}
