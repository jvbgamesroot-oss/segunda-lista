#include <stdio.h>

int main(void) {
    int v[6], i, n;

    /* le 6 valores pares (repete a leitura se nao for par) */
    for (i = 0; i < 6; i++) {
        do {
            printf("Digite o valor par %d: ", i + 1);
            scanf("%d", &n);
            if (n % 2 != 0)
                printf("Valor invalido! Digite um numero par.\n");
        } while (n % 2 != 0);
        v[i] = n;
    }

    printf("Ordem inversa:\n");
    for (i = 5; i >= 0; i--)
        printf("%d\n", v[i]);

    return 0;
}
