#include <stdio.h>

int main(void) {
    float v[10], somaPos = 0;
    int i, negativos = 0;

    for (i = 0; i < 10; i++) {
        printf("Digite o valor %d: ", i + 1);
        scanf("%f", &v[i]);
        if (v[i] < 0)
            negativos++;
        else if (v[i] > 0)
            somaPos += v[i];
    }

    printf("Quantidade de negativos: %d\n", negativos);
    printf("Soma dos positivos: %.2f\n", somaPos);

    return 0;
}
