#include <stdio.h>

int main(void) {
    float nota[15], soma = 0;
    int i;

    for (i = 0; i < 15; i++) {
        printf("Nota do aluno %d: ", i + 1);
        scanf("%f", &nota[i]);
        soma += nota[i];
    }

    printf("Media geral: %.2f\n", soma / 15);

    return 0;
}
