#include <stdio.h>

int main(void) {
    float v[5], maior, menor, soma = 0;
    int i;

    for (i = 0; i < 5; i++) {
        printf("Digite o valor %d: ", i + 1);
        scanf("%f", &v[i]);
        soma += v[i];
    }

    maior = menor = v[0];
    for (i = 1; i < 5; i++) {
        if (v[i] > maior) maior = v[i];
        if (v[i] < menor) menor = v[i];
    }

    printf("Valores lidos: ");
    for (i = 0; i < 5; i++)
        printf("%.2f ", v[i]);
    printf("\nMaior: %.2f\nMenor: %.2f\nMedia: %.2f\n", maior, menor, soma / 5);

    return 0;
}
